//377
let d377 = document.querySelector('.d377');
let btn377 = document.querySelector('#btn377');
btn377.addEventListener('click', function(){
    d377.style.height = '100px';
    d377.style.width = '100px';
    d377.style.border = '5px solid black';
})

//378
let d378 = document.querySelector('.d378');
let btn378 = document.querySelector('#btn378');
btn378.addEventListener('click', function(){
    d378.style.fontSize = '20px';
    d378.style.borderTop = '2px solid black';
    d378.style.backgroundColor = 'red';
})

//379
let elem379 = document.querySelector('#elem379');
let btn379 = document.querySelector('#btn379');
let li379 = document.querySelectorAll('.li279')
btn379.addEventListener('click', function(){
    for(let elem of li379){
        elem.style.cssFloat('left')
    }
})

//380
let p380 = document.querySelector('#p380');
let btn380_1 = document.querySelector('#btn380_1');
let btn380_2 = document.querySelector('#btn380_2');
let btn380_3 = document.querySelector('#btn380_3');
btn380_1.addEventListener('click', function(){
    p380.classList.add('textdec');
})
btn380_2.addEventListener('click', function(){
    p380.classList.add('bolder');
})
btn380_3.addEventListener('click', function(){
    p380.classList.add('colored');
})

//381
let p381 = document.querySelector('#p381');
let btn381_1 = document.querySelector('#btn381_1');
let btn381_2 = document.querySelector('#btn381_2');
let btn381_3 = document.querySelector('#btn381_3');
btn381_1.addEventListener('click', function(){
    p381.classList.toggle('textdec');
})
btn381_2.addEventListener('click', function(){
    p381.classList.toggle('bolder');
})
btn381_3.addEventListener('click', function(){
    p381.classList.toggle('colored');
})