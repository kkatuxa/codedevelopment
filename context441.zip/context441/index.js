//435 
let elem435 = document.querySelector('#elem435'); 
elem435.addEventListener('blur', func435); 
 
function func435(){ 
    let temp = this; 
    function square(){ 
        let num = temp.value * temp.value; 
        return num; 
    } 
    alert(square()); 
} 
 
//438 
elem438_1 = document.querySelector('#elem438_1'); 
elem438_2 = document.querySelector('#elem438_2'); 
elem438_3 = document.querySelector('#elem438_3'); 
function func() { 
 console.log(this.value); 
} 
func.call(elem438_1); 
func.call(elem438_2); 
func.call(elem438_3); 
 
//439 
let elem439 = document.querySelector('#elem439'); 
 
function func439(surname, name) { 
 console.log(this.value + ', ' + name + ' ' +  
  surname);  
} 
 
func439.call(elem439, 'Smit','John'); 
 
//440 
func439.apply(elem439, ['Smit','John']);

//441
let elem441 = document.getElementById('elem441');

function func441(name, surname) {
	console.log(this.value + ', ' + name + ' ' + surname);
}

newFunc441 = func441.bind(elem441);// тут напишите конструкцию с bind()

newFunc441('John', 'Smit'); // тут должно вывести 'hello, John Smit'
newFunc441('Eric', 'Luis'); // тут должно вывести 'hello, Eric Luis'