// //442
// setInterval(function(){
//     console.log('hello')
// }, 3000)

// //443
// let i443 = 100;
// setInterval(()=> console.log(--i443),1000);

// //444
// let temp444 = 10;
// let timerId444 = setInterval(function(){
//     console.log(temp444--);
//     if (temp444 == 0){
//         clearInterval(timerId444);
//     }
// },1000)

// //445
// let btn445 = document.querySelector('#btn445');
// btn445.addEventListener('click', function func445(){
//     let i = 100;

//     setInterval(()=> console.log(i--),500)
//     this.removeEventListener('click', func445);
// })

// //447
// let temp447 = 10;
// let timerId447;
// let btn447_1 = document.querySelector('#btn447_1');
// let btn447_2 = document.querySelector('#btn447_2');
// btn447_1.addEventListener('click', function func447(){
//     timerId447 = setInterval(function(){
//         console.log(temp447--);
//         if (temp447 == 0){
//             clearInterval(timerId447);
//         }
//     }, 500)
// })
// btn447_2.addEventListener('click', function(){
//     clearInterval(timerId447);
// })

// //448
// let inp448 = document.querySelector('#elem448');
// let timerId448 = setInterval(function(){
//     elem448.value = Number(elem448.value) - 1;
//     console.log(elem448.value);

//     if (elem448.value == 0){
//         clearInterval(timerId448);
//     }
// },500)

//450 Практика
//1
let btn1 = document.querySelector('#btn1');
let pelem1 = document.querySelector('#pelem1');
btn1.addEventListener('click', function(){
    setInterval(function(){
        pelem1.textContent = Number(pelem1.textContent) + 1;
    }, 1000)
})
//2
let btn2 = document.querySelector('#btn2');
let pelem2 = document.querySelector('#pelem2');
btn2.addEventListener('click', function(){
    let timerId2 = setInterval(function(){
        pelem2.textContent = Number(pelem2.textContent) - 1;
        if (Number(pelem2.textContent) == 0){
            clearInterval(timerId2);
        }
    }, 1000)
})

//3
let inp3 = document.querySelector('#inp3');
setInterval(function(){
    inp3.value = inp3.value * inp3.value;
},1000)

//4
let inp4 = document.querySelector('#inp4');
inp4.addEventListener('blur', function(){
    let timerId4 = setInterval(function(){
        inp4.value = inp4.value - 1;
        if (inp4.value == 0){
            clearInterval(timerId4);
        }
    },1000)
})

//5
let inp5 = document.querySelector('#inp5');
let btn5 = document.querySelector('#btn5');
let pelem5 = document.querySelector('#pelem5');
btn5.addEventListener('click', function(){
    let temp = inp5.value;
    let timerId5 = setInterval(function(){
        pelem5.textContent = temp--;
        if (temp == 0){
            clearInterval(timerId5);
        }
    }, 1000)
})

//6
let pelem6 = document.querySelector('#pelem6');
let btn6_1 = document.querySelector('#btn6_1');
let btn6_2 = document.querySelector('#btn6_2');
let timerId6;
btn6_1.addEventListener('click', function(){
    timerId6 = setInterval(function(){
        pelem6.textContent = Number(pelem6.textContent) + 1;
    },1000)
})
btn6_2.addEventListener('click', function(){
    clearInterval(timerId6);
})

//7
let pelem7 = document.querySelector('#pelem7');
setInterval(function(){
    pelem7.classList.toggle('colorgreen');
},1000)

//8
let pelem8 = document.querySelector('#pelem8');
let date = new Date();
let btn8 = document.querySelector('#btn8');
btn8.addEventListener('click', function(){
    let timerId8 = setInterval(function(){
        pelem8.textContent = date.getHours() + ' ' + date.getMinutes() + ' ' + date.getSeconds();
    },1000)
})

//451
let pelem451 = document.querySelector('#pelem451');
setTimeout(function() {
    pelem451.textContent = 'hello';
}, 10000);

//452
let i = 1;
let k = 1000;
function timer() {
	setTimeout(function() {
		console.log(++i);
		k = k+1000;
		timer(); // вызовем сами себя
	}, k);
}
timer();