//365.1
let elem365 = document.querySelector('#elem365');
let value365 = elem365.getAttribute('value');
console.log(value365);

//365.2
let elem365_1 = document.querySelector('#elem365_1');
let value365_1 = elem365_1.getAttribute('class');
console.log(value365_1);

//366.1
let elem366 = document.querySelector('#elem366');
elem366.setAttribute('value', 'text');

//366.2
let elem366_1 = document.querySelector('#elem366_1');
elem366_1.setAttribute('class', 'valid');

//367
let elem367 = document.querySelector('#elem367');
elem367.removeAttribute('value');

//368
let elem368 = document.querySelector('#elem368');
console.log(elem368.hasAttribute('value'));

//369.1
let elem369_1 = document.querySelector('#elem369_1');
elem369_1.addEventListener('click', function(){
    elem369_1.textContent += elem369_1.getAttribute('data-text');
})

//369.2
let d369 = document.querySelectorAll('.d369');
for (let elem of d369){
    elem.addEventListener('click', function(){
        elem.textContent += elem.getAttribute('data-num');
    })
}

//369.3
let btn369_1 = document.querySelector('#btn369_1');
let btn369_2 = document.querySelector('#btn369_2');
btn369_1.addEventListener('click', function(){
    btn369_1.setAttribute('data-count', Number(btn369_1.getAttribute('data-count'))+1);
})
btn369_2.addEventListener('click', function(){
    console.log(btn369_1.getAttribute('data-count'));
})

//369.4
let inp369_4 = document.querySelector('#elem369_4');
inp369_4.addEventListener('blur', function(){
    if (inp369_4.value.length < inp369_4.getAttribute('data-length')){
        inp369_4.value = 'ну жесть';
    }
})

//369.5
let inp369_5 = document.querySelector('#elem369_5');
inp369_5.addEventListener('blur', function(){
    if (inp369_5.value.length < inp369_5.getAttribute('data-min')){
        inp369_5.value = 'ну жесть мало';
    }else if(inp369_5.value.length > inp369_5.getAttribute('data-max'))
    {
        inp369_5.value = 'ну жесть много';
    }
})

//370
let d370 = document.querySelector('#elem370');
d370.addEventListener('click', function(){
    d370.textContent = Number(d370.dataset.productPrice) * Number(d370.dataset.productAmount);
})

//371
let p371 = document.querySelectorAll('.p371');
let i = 1;
for(let elem of p371){
    elem.setAttribute('data-num', i++);
    console.log(elem.getAttribute('data-num'));
}

//372.1
let p372_1 = document.querySelector('#elem372_1');
let len = p372_1.classList.length;
console.log(len);

//372.2
let p372_2 = document.querySelector('#elem372_2');
let arr372 = p372_1.classList;
for(let elem of arr372){
    console.log(elem);
}

//373
let p373 = document.querySelector('#elem373');
p373.classList.add('xxx');
console.log(p373.getAttribute('class'))

//374
let p374 = document.querySelector('#elem374');
p374.classList.remove('www','zzz');
console.log(p374.getAttribute('class'));

//375
let p375 = document.querySelector('#elem375');
console.log(p375.classList.contains('ggg'));

//376
let p376 = document.querySelector('#elem376');
p376.classList.toggle('www')