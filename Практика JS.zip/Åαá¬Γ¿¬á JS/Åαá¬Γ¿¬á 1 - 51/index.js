// 1 
// 1.1
let elem1 = document.querySelector('#elem1');
let but1 = document.querySelector('#button1');
let but01 = document.querySelector('#button01');
let p1 = document.querySelector('#p1');
but1.addEventListener('click', ()=> {
    p1.textContent = elem1.value **2;
});
but01.addEventListener('click', ()=> {
    p1.textContent = elem1.value *4;
});

// 1.2
let elem2 = document.querySelector('#elem2');
let elem02 = document.querySelector('#elem02');
let but2 = document.querySelector('#button2');
let but02 = document.querySelector('#button02');
let p2 = document.querySelector('#p2');
but2.addEventListener('click', ()=> {
    p2.textContent = elem2.value*elem02.value;
});
but02.addEventListener('click', ()=> {
    p2.textContent = (Number(elem2.value) + Number(elem02.value))*2;
});

// 1.3
let elem3 = document.querySelector('#elem3');
let but3 = document.querySelector('#button3');
let but03 = document.querySelector('#button03');
let p3 = document.querySelector('#p3');
but3.addEventListener('click', ()=> {
    p3.textContent = 3.14*(elem3.value**2);
});
but03.addEventListener('click', ()=> {
    p3.textContent = (3.14*elem3.value)*2;
});

// 1.4
document.getElementById("button4").addEventListener("click", function() {
    let a = parseFloat(document.getElementById("elem4").value);
    let b = parseFloat(document.getElementById("elem04").value);
    let c = parseFloat(document.getElementById("elem004").value);
    if (a + b > c && a + c > b && b + c > a) {
        let s = (a + b + c) / 2;
        let area = Math.sqrt(s * (s - a) * (s - b) * (s - c));
        document.getElementById("p4").textContent = "Площадь треугольника: " + area;
    } else {
        document.getElementById("p4").textContent = "Треугольник с такими сторонами не существует";
    }
});

// 2 
// 2.1
document.getElementById("button5").addEventListener("click", function() {
    let a = parseFloat(document.getElementById("a5").value);
    let b = parseFloat(document.getElementById("b5").value);
    let c = parseFloat(document.getElementById("c5").value);
    let d5 = b * b - 4 * a * c;
    if (d5 > 0) {
        let x1 = (-b + Math.sqrt(d5)) / (2 * a);
        let x2 = (-b - Math.sqrt(d5)) / (2 * a);
        document.getElementById("roots").textContent = "Корни уравнения: x1 = " + x1 + ",  x2 = " + x2;
    } else if (d5 === 0) {
        let x = -b / (2 * a);
        document.getElementById("roots").textContent = "Уравнение имеет один корень: x = " + x;
    } else {
        document.getElementById("roots").textContent = "Уравнение не имеет действительных корней";
    }
});

// 2.2
document.getElementById("button6").addEventListener("click", function() {
    let num1 = parseFloat(document.getElementById("num61").value);
    let num2 = parseFloat(document.getElementById("num62").value);
    let num3 = parseFloat(document.getElementById("num63").value);
    let maxNum = Math.max(num1, num2, num3);
    if (maxNum === num1) {
        if (num1 * num1 === num2 * num2 + num3 * num3) {
            document.getElementById("p6").textContent = "Это тройка Пифагора";
        } else {
            document.getElementById("p6").textContent = "Это не тройка Пифагора";
        }
    } else if (maxNum === num2) {
        if (num2 * num2 === num1 * num1 + num3 * num3) {
            document.getElementById("p6").textContent = "Это тройка Пифагора";
        } else {
            document.getElementById("p6").textContent = "Это не тройка Пифагора";
        }
    } else {
        if (num3 * num3 === num1 * num1 + num2 * num2) {
            document.getElementById("p6").textContent = "Это тройка Пифагора";
        } else {
            document.getElementById("p6").textContent = "Это не тройка Пифагора";
        }
    }
});

// 2.3
document.getElementById("button7").addEventListener("click", function() {
    let number7 = parseInt(document.getElementById("num7").value);
    let d7 = [];
    for (let i7 = 1; i7 <= number7; i7++) {
        if (number7 % i7 === 0) {
            d7.push(i7);
        }
    }
    document.getElementById("d7").textContent = "Делители числа: " + d7.join(", ");
});

// 2.4
document.getElementById("button8").addEventListener("click", function() {
    let num81 = parseInt(document.getElementById("num81").value);
    let num82 = parseInt(document.getElementById("num82").value);
    let d8 = [];
    for (let i8 = 1; i8 <= Math.min(num81, num82); i8++) {
        if (num81 % i8 === 0 && num82 % i8 === 0) {
            d8.push(i8);
        }
    }
    let l8 = document.getElementById("d8");
    l8.textContent = "";
    d8.forEach(function(divisor) {
        let li8 = document.createElement("li");
        li8.textContent = divisor;
        l8.appendChild(li8);
    });
});
 
// 2.5
function find9(a, b) {
    if (b === 0) {
        return a;
    } else {
        return find9(b, a % b);
    }
}
document.getElementById("button9").addEventListener("click", function() {
    let num91 = parseInt(document.getElementById("num91").value);
    let num92 = parseInt(document.getElementById("num92").value);
    let res9 = find9(num91, num92);
    document.getElementById("p9").textContent = "Наибольший общий делитель: " + res9;
});

// 2.6
function find10(a, b) {
    return Math.abs(a * b) / find9(a, b);
}
document.getElementById("button10").addEventListener("click", function() {
    let num10 = parseInt(document.getElementById("num10").value);
    let num101 = parseInt(document.getElementById("num101").value);
    let p10 = find10(num10, num101);
    document.getElementById("p10").textContent = "Наименьшее число, которое делится и на " + num10 + ", и на " + num101 + ": " + p10;
});

// 3 

let secretNumber = Math.floor(Math.random() * 100) + 1;
let try11 = 0;
document.getElementById("button11").addEventListener("click", function() {
    let guess11 = parseInt(document.getElementById("guess11").value);
    if (guess11 < 1 || guess11 > 100 || isNaN(guess11)) {
        document.getElementById("result").textContent = "Введите число от 1 до 100.";
    } else {
        try11++;
        if (guess11 === secretNumber) {
            document.getElementById("res11").textContent = "Поздравляем! Вы угадали число " + secretNumber + " за " + try11 + " попыток.";
        } else if (guess11 < secretNumber) {
            document.getElementById("res11").textContent = "Введите число побольше.";
        } else {
            document.getElementById("res11").textContent = "Введите число поменьше.";
        }
    }
});

// 4 
let selectedCells = [];
let foundCells = 0;
function random4() {
    selectedCells = [];
    while (selectedCells.length < 10) {
        let randomCell = Math.floor(Math.random() * 100);
        if (!selectedCells.includes(randomCell)) {
            selectedCells.push(randomCell);
        }
    }
}
function checkCell(cellIndex) {
    if (selectedCells.includes(cellIndex)) {
        foundCells++;
        document.getElementById("cell" + cellIndex).style.backgroundColor = "green";
    } else {
        document.getElementById("cell" + cellIndex).style.backgroundColor = "red";
    }

    if (foundCells === 10) {
        document.getElementById("message4").textContent = "Поздравляем! Вы нашли все загаданные клетки!";
    }
}
function createTable() {
    let table = document.getElementById("gameTable");
    for (let i = 0; i < 5; i++) {
        let row = table.insertRow();
        for (let j = 0; j < 5; j++) {
            let cellIndex = i * 5 + j;
            let cell = row.insertCell();
            cell.id = "cell" + cellIndex;
            cell.textContent = cellIndex;
            cell.addEventListener("click", function() {
                checkCell(parseInt(this.id.slice(4)));
            });
        }
    }
}
random4();
createTable();

// 5 
let keyboard5 = [
    '1', '2', '3', '4', '5', '6', '7', '8', '9', '0',
    'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p',
    'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l',
    'z', 'x', 'c', 'v', 'b', 'n', 'm', 'Caps Lock'
];
let capsLock5 = false;
let elem5 = document.getElementById('elem5');
let keyb5 = document.getElementById('keyboard');
keyboard5.forEach(key => {
    let keyButton = document.createElement('button');
    keyButton.textContent = key;
    keyButton.addEventListener('click', () => {
        if (key === 'Caps Lock') {
            capsLock5 = !capsLock5;
            return;
        }
        if (capsLock5) {
            elem5.value += key.toUpperCase();
        } else {
            elem5.value += key;
        }
    });
    keyb5.appendChild(keyButton);
});

// 6 
let calendar6 = document.getElementById('calendar6');
let date6 = document.getElementById('date6');
let currentDate = new Date();
let currentMonth = currentDate.toLocaleString('ru', { month: 'long' });
let currentYear = currentDate.getFullYear();
date6.textContent = currentMonth+' '+currentYear;
for (let i = 1; i <= new Date(currentYear, currentDate.getMonth() + 1, 0).getDate(); i++) {
    let day = document.createElement('li');
    day.textContent = i;
    if (i === currentDate.getDate()) {
        day.classList.add('current-day');
    }
    calendar6.appendChild(day);
}

// 8
let input8 = document.getElementById('elem8');
let table8 = document.getElementById('table8');
let events = {
    2010: "Перепись населения в России",
    2011: "Родился семимиллиардный житель Земли",
    2012: "Несостоявшийся конец света или смена лидеров двух крупнейших государств",
    2013: "Смерть Маргарет Тэтчер",
    2014: "Олимпиада в Сочи",
    2015: "Семидесятилетие Победы в Великой Отечественной войне",
    2016: "Дональд Трамп избран президентом США",
    2017: "Первый в мире электрический грузовик",
    2018: "Чемпионат мира по футболу в России",
    2019: "Пожар в Нотр-Дам-де-Пари",
    2020: "Пандемия коронавирусной инфекции"
};
input8.addEventListener('keyup', function(event) {
    if (event.key === 'Enter') {
        let year = parseInt(input8.value);
        if (events[year]) {
            table8.textContent = year+' '+events[year];
        } else {
            table8.textContent = 'Событий не найдено';
        }
    }
});

// 9 
let date9 = document.getElementById('date9');
let radios = document.querySelectorAll('input[type=radio]');
let horoscopeDiv = document.getElementById('horoscope');
function getHoroscope(sign9, day9) {
    let horoscopes = {
        овен: {
            Сегодня: "Сегодня: Вам стоит быть активным и решительным. Возможно, встретится новая возможность.",
            Завтра: "Завтра: Подготовьтесь к неожиданным изменениям. Будьте готовы к адаптации. вас ждут новые возможности для самовыражения.",
            Послезавтра: "Послезавтра: Сосредоточьтесь на саморазвитии. Обратите внимание на свои личные цели."
        },
        телец: {
            today: "Сегодня: Сфокусируйтесь на финансовых вопросах. Будьте внимательны к своим расходам.",
            tomorrow: "Завтра: Возможно, встретится новый человек, который принесет в вашу жизнь что-то новое.",
            dayAfterTomorrow: "Послезавтра: Посвятите время отдыху и релаксации. Найдите способы снять стресс."
        },
        близнецы: {
            today: "Сегодня: Будьте готовы к общению и обмену информацией. Возможно, новые идеи придут легко.",
            tomorrow: "Завтра: Сосредоточьтесь на своих обязательствах. Будьте организованными.",
            dayAfterTomorrow: "Послезавтра: Поставьте перед собой ясные цели. Работайте над их достижением."
        },
        рак: {
            today: "Сегодня: Позаботьтесь о своем доме и близких. Семейные отношения могут быть особенно важны.",
            tomorrow: "Завтра: Будьте открыты к новым возможностям. Используйте свою интуицию.",
            dayAfterTomorrow: "Послезавтра: Обратите внимание на свое здоровье. Займитесь физическими упражнениями. "
        },
        лев: {
            today: "Сегодня: Покажите свою творческую сторону. Будьте уверены в себе.",
            tomorrow: "Завтра: Возможно, придется принять лидирующую роль. Будьте готовы к ответственности.",
            dayAfterTomorrow: "Послезавтра: Общение с окружающими будет ключевым. Выразите свои мысли и чувства."
        },
        дева: {
            today: "Сегодня: Будьте осторожны в принятии решений. Проверьте все детали.",
            tomorrow: "Завтра: Сосредоточьтесь на своей работе или обязанностях. Будьте методичны.",
            dayAfterTomorrow: "Послезавтра: Найдите баланс между работой и отдыхом. Позаботьтесь о своем благополучии."
        },
        весы: {
            today: " Сегодня: Сосредоточьтесь на отношениях с другими людьми. Будьте дипломатичны.",
            tomorrow: "Завтра: Сосредоточьтесь на своей работе или обязанностях. Будьте методичны.",
            dayAfterTomorrow: "Послезавтра: Поставьте перед собой ясные цели и планы на будущее. Действуйте последовательно."
        },
        скорпион: {
            today: "Сегодня: Ищите новые приключения и возможности для роста. Будьте оптимистичны.",
            tomorrow: "Завтра: Поставьте перед собой ясные цели и стратегии для их достижения.",
            dayAfterTomorrow: "Послезавтра: Общение с окружающими будет ключевым. Будьте открыты к новым знакомствам.            "
        },
        стрелец: {
            today: "Сегодня: Ищите новые приключения и возможности для роста. Будьте оптимистичны.",
            tomorrow: " Завтра: Поставьте перед собой ясные цели и стратегии для их достижения.",
            dayAfterTomorrow: "Послезавтра: Общение с окружающими будет ключевым. Будьте открыты к новым знакомствам."
        },
        козерог: {
            today: "Сегодня: Сосредоточьтесь на своих целях и амбициях. Будьте настойчивыми.",
            tomorrow: "Завтра: Постарайтесь найти баланс между работой и личной жизнью.",
            dayAfterTomorrow: " Послезавтра: Будьте осторожны в принятии решений. Проверяйте все детали."
        },
        водолей: {
            today: "Сегодня: Будьте открыты к новым идеям и возможностям. Общение с другими будет ключевым.",
            tomorrow: "- Завтра: Используйте свою интуицию и креативность для решения проблем.",
            dayAfterTomorrow: "Послезавтра: Обратите внимание на свои личные отношения. Позаботьтесь о близких."
        },
        рыбы: {
            today: "Позаботьтесь о своем внутреннем равновесии и спокойствии.",
            tomorrow: "Завтра: Будьте готовы к неожиданным событиям. Используйте свою интуицию.",
            dayAfterTomorrow: "Послезавтра: Найдите время для творчества и самовыражения. Обратите внимание на свои хобби."
        }
    };
    if (horoscopes[sign9.toLowerCase()] && horoscopes[sign9.toLowerCase()][day9]) {
        return horoscopes[sign9.toLowerCase()][day9];
    } else {
        return 'Прогноз не найден';
    }
}
date9.addEventListener('keyup', function(event) {
    if (event.key === 'Enter') {
        let birthdate = new Date(date9.value);
        let selected9 = document.querySelector('input[name=day]:checked').value;
        let sign9 = '';
        let day9 = birthdate.getDate();
        let month9 = birthdate.getMonth() + 1;
        if ((month9 === 3 && day9 >= 21) || (month9 === 4 && day9 <= 20)) {
            sign9 = 'Овен';
        } else if ((month9 === 4 && day9 >= 21) || (month9 === 5 && day9 <= 20)) {
            sign9 = 'Телец';
        }
        let horoscope = getHoroscope(sign9, selected9);
        horoscopeDiv.textContent = horoscope;
    }
});

// 10 
let timerId;
let res10;
function getRandomNumber(max) {
    return Math.floor(Math.random() * max) + 1;
}
document.getElementById('start10').addEventListener('click', function() {
    let timerElement = document.getElementById('timer10');
    timerId = setInterval(function() {
        timerElement.textContent = getRandomNumber(10);
    }, 100);
    this.classList.remove('active');
    document.getElementById('stop10').classList.add('active');
});
document.getElementById('stop10').addEventListener('click', function() {
    clearInterval(timerId);
    res10 = document.getElementById('timer10').textContent;
    if (res10 == 1) {
        document.getElementById('text10').textContent = 'сегодня тебя ждет успех!';
    } else if (res10 == 2) {
        document.getElementById('text10').textContent = 'сегодня ты встретишь свою родную душу';
    } else if (res10 == 3) {
        document.getElementById('text10').textContent = 'тебе повезёт сегодня';
    } else if (res10 == 4) {
        document.getElementById('text10').textContent = 'верь в себя и всё получится';
    } else if (res10 == 5) {
        document.getElementById('text10').textContent = 'смотри под ноги';
    } else if (res10 == 6) {
        document.getElementById('text10').textContent = 'посоветуйся с кем-то более мудрым если у тебя будет сложный выбор';
    } else if (res10 == 7) {
        document.getElementById('text10').textContent = 'твой друг тебе врёт';
    } else if (res10 == 8) {
        document.getElementById('text10').textContent = 'послушай музыку и успокойся';
    } else if (res10 == 9) {
        document.getElementById('text10').textContent = 'сегодняшний день отлично подходит для отдыха на свежем воздухе';
    } else if (res10 == 10) {
        document.getElementById('text10').textContent = 'попробуйте сегодня что-нибудь новое';
    };
    this.classList.remove('active');
});

// 11 
let arr  = ['Belarus', 'Belgium', 'Bulgaria'];
let elem = document.querySelector('#elem11');
let list = document.querySelector('#list11');
elem.addEventListener('input', function() {
    list.textContent = '';
    if (this.value !== '') {
        let matches = arr.filter(item => item.startsWith(this.value));
        if (matches.length > 0) {
            for (let match of matches) {
                let li = document.createElement('li');
                li.textContent = match;
                list.appendChild(li);
                li.addEventListener('click', function() {
                    elem.value = this.textContent;
                    list.textContent = '';
                });
            }
        }
    }
});

// 12 
let toggles = document.querySelectorAll('.toggle');
toggles.forEach(toggle => {
    toggle.addEventListener('click', function() {
        let spoiler = this.parentElement.nextElementSibling;
        spoiler.classList.toggle('.active');
    });
});

// 13 
let parent13 = document.querySelector('#parent13');
let links13  = parent13.querySelectorAll('.menu a');
let tabs   = parent13.querySelectorAll('.tab');
for (let i = 0; i < links13.length; i++) {
    links13[i].addEventListener('click', function(event) {
        let activeLink = parent13.querySelector('.menu a.active');
        activeLink.classList.remove('active');
        let activeTab = parent13.querySelector('.tab.active');
        activeTab.classList.remove('active');
        tabs[i].classList.add('active');
        this.classList.add('active');
        event.preventDefault();
    });
}

// 14 
let parent14 = document.querySelector('#parent14');
let links  = parent14.querySelectorAll('.tab14 .link14 a');
for (let link of links) {
    link.addEventListener('click', function(event) {
        let activeTab = parent14.querySelector('.tab14.active14');
        if (activeTab) {
            activeTab.classList.remove('active');
        }
        let newTab = link.closest('.tab14');
        if (newTab !== activeTab) {
            newTab.classList.add('active');
        }
        event.preventDefault();
    });
}



// 15 
let cities = []; 
let player15 = 1; 
function vvod() {
    let input15 = document.getElementById("elem15");
    let city15 = input15.value.trim(); 
    if (city15 === "") {
        showMessage("Сначала введите город"); 
        return;
    }
    if (cities.length > 0) {
        let lastCity = cities[cities.length - 1];
        if (city15[0].toLowerCase() !== lastCity[lastCity.length - 1].toLowerCase()) {
            showMessage("Название города должно начинаться с последней буквы предыдущего города");
            return;
        }
        if (cities.includes(city15.toLowerCase())) {
            showMessage("Этот город уже был введен");
            return;
        }
    }
    cities.push(city15.toLowerCase());
    showMessage("последний введенный город: " + city15);

    player15 = player15 === 1 ? 2 : 1; 

    input15.value = "";
}
function showMessage(text) {
    let message15 = document.getElementById("message15");
    message15.textContent = text;
}

// 18 
let input18 = document.querySelector('#input18');
let list18 = document.querySelector('#list18');
input18.addEventListener('keypress', function(event) {
    if (event.key == 'Enter') {
        let li18 = document.createElement('li');
        let task18 = document.createElement('span');
        task18.classList.add('task');
        task18.textContent = this.value;
        task18.addEventListener('dblclick', function() {
            let text18 = this.textContent;
            this.textContent = '';
            let edit18 = document.createElement('input');
            edit18.value = text18;
            this.appendChild(edit18);
            let self18 = this;
            edit18.addEventListener('keypress', function(event) {
                if (event.key == 'Enter') {
                    self18.textContent = this.value;
                }
            });
        });
        li18.appendChild(task18);
        let remove18 = document.createElement('span');
        remove18.textContent = ' удалить ';
        remove18.style.color = 'red';
        remove18.classList.add('remove');
        remove18.addEventListener('click', function() {
            this.parentElement.remove();
        });
        li18.appendChild(remove18);
        let mark18 = document.createElement('span');
        mark18.textContent = ' сделано';
        mark18.style.color = 'green';
        mark18.classList.add('mark');
        mark18.addEventListener('click', function() {
            this.parentElement.style.textDecoration = 'line-through';
        });
        li18.appendChild(mark18);
        list18.appendChild(li18);
        this.value = '';
    }
});

// 24 
let name   = document.querySelector('#name');
let price  = document.querySelector('#price');
let amount = document.querySelector('#amount');
let add    = document.querySelector('#add');
let table  = document.querySelector('#table');
let total  = document.querySelector('#total');
add.addEventListener('click', function() {
    let tr = document.createElement('tr');
    edit24(create24(tr, name.value, 'name'));
    edit24(create24(tr, price.value, 'price'));
    edit24(create24(tr, amount.value, 'amount'));
    create24(tr, price.value * amount.value, 'cost');
    create24(tr, 'удалить', 'remove').addEventListener('click', function() {
        this.parentElement.parentElement.removeChild(this.parentElement);
        res24();
    });
    table.appendChild(tr);
    res24();
});
function create24(tr, value, name) {
    let td = document.createElement('td');
    td.textContent = value;
    td.classList.add(name);
    tr.appendChild(td);
    return td;
}
function edit24(td) {
    td.addEventListener('dblclick', function() {
        let text = td.textContent
        td.textContent = '';
        let input = document.createElement('input');
        input.value = text;
        input.focus();
        td.appendChild(input);
        input.addEventListener('keydown', function(event) {
            if (event.key == 'Enter') {
                td.textContent = this.value;
                if (td.classList.contains('price') || td.classList.contains('amount')) {
                    let tr = td.parentElement;
                    let price = tr.querySelector('.price');
                    let amount = tr.querySelector('.amount');
                    let cost = tr.querySelector('.cost');
                    cost.textContent = price.textContent * amount.textContent;
                    res24();
                }
            }
        });
    });
}
function res24() {
    let costs = table.querySelectorAll('.cost');
    if (costs) {
        let sum = 0;
        for (let cost of costs) {
            sum += +cost.textContent;
        }
        total.textContent = sum;
    }
}


// 30 
let input1 = document.querySelector('#elem30_1');
input1.addEventListener('keyup', function(event) {
    if (event.key === 'Enter') {
        let value = input1.value.trim();
        if (value === '4') {
            input1.classList.add('right');
        } else {
            input1.classList.add('wrong');
        }
    }
});
let input2 = document.querySelector('#elem30_2');
input2.addEventListener('keyup', function(event) {
    if (event.key === 'Enter') {
        let value = input2.value.trim();
        if (value === 'среда') {
            input2.classList.add('right');
        } else {
            input2.classList.add('wrong');
        }
    }
});
let input3 = document.querySelector('#elem30_3');
input3.addEventListener('keyup', function(event) {
    if (event.key === 'Enter') {
        let value = input3.value.trim();
        if (value === '12') {
            input3.classList.add('right');
        } else {
            input3.classList.add('wrong');
        }
    }
});

// 32
let answers32 = [
    'Москва',
    'Рим',
    'Вашингтон',
];
let questions = [
    'столица России?',
    'столица Италии?',
    'столица США?'
];
let test32 = document.getElementById('test32');
let button = document.getElementById('button32');
function createQuestionHTML(question, _index) {
    let div32 = document.createElement('div');
    let question32 = document.createElement('p');
    let answer32 = document.createElement('input');
    question32.textContent = question;
    answer32.placeholder = 'Введите ответ';
    div32.appendChild(question32);
    div32.appendChild(answer32);
    test32.appendChild(div32);
}
questions.forEach((question, index) => {
    createQuestionHTML(question, index);
});
button.addEventListener('click', function() {
    let inputs = test32.querySelectorAll('input');
    let allCorrect = true;
    inputs.forEach((input, index) => {
        if (input.value.toLowerCase() !== answers32[index].toLowerCase()) {
            allCorrect = false;
        }
    });
    if (allCorrect) {
        alert('Все ответы верные!');
    } else {
        alert('Есть ошибки в ответах.');
    }
});

// 34 
// let answers34 = [
//     'ответ 1',
//     'ответ 2',
//     'ответ 3',
// ];
// let questions34 = [
//     'вопрос 1?',
//     'вопрос 2?',
//     'вопрос 3?'
// ];
// let test34 = document.getElementById('test34');

// function createQuestionHTML(question34, index34) {
//     let div34 = document.createElement('div');
//     let q34 = document.createElement('p');
//     q34.textContent = question34;
//     div34.appendChild(q34);
//     answers34.forEach((answer34) => {
//         let ainp34 = document.createElement('input');
//         ainp34.type = 'radio';
//         ainp34.name = question34[index34];
//         ainp34.value = answer34;
//         ainp34.addEventListener('change', function() {
//             if (ainp34.checked) {
//                 if (ainp34.value.toLowerCase() === answers34[index34].toLowerCase()) {
//                     alert('Правильный ответ!');
//                 } else {
//                     alert('Неправильный ответ!');
//                 }
//             }
//         });
//         let label34 = document.createElement('label');
//         label34.textContent = answer34;
//         div34.appendChild(ainp34);
//         div34.appendChild(label34);
//     });
//     test34.appendChild(div34);
// }
// questions34.forEach((question34, index34) => {
//     createQuestionHTML(question34, index34);
// });

// 
// 
let texts37 = ['text1', 'text2', 'text3'];
let current37 = 0;
let slide37 = document.getElementById('slider37');

function updateText37() {
    slide37.textContent = texts37[current37];
    current37 = (current37 + 1) % texts37.length; 
}
setInterval(updateText37, 1000);

// 38 
let texts = ['text1', 'text2', 'text3'];
let current38 = 0;
let slide38 = document.getElementById('slider38');
let leftArrow = document.getElementById('left');
let rightArrow = document.getElementById('right');
function updateText38() {
    slide38.textContent = texts[current38];
}
function decreaseIndex() {
    current38 = (current38 - 1 + texts.length) % texts.length; 
    updateText38();
}
function increaseIndex() {
    current38 = (current38 + 1) % texts.length; 
    updateText38();
}
leftArrow.addEventListener('click', decreaseIndex);
rightArrow.addEventListener('click', increaseIndex);
updateText38(); 

// 39 
let images = ['img/image1.jpg', 'img/image2.jpg', 'img/image3.jpg'];
let currentIndex = 0;
let sliderElement = document.getElementById('slider');
function updateImage() {
    sliderElement.src = images[currentIndex];
}
function nextImage() {
    currentIndex = (currentIndex + 1) % images.length; 
    updateImage();
}
setInterval(nextImage, 1000);
updateImage();

// 41 
let board = document.querySelector('.board');
let currentPlayer = 'X';
let cells = Array.from({ length: 9 });
cells.forEach((_, index) => {
    let cell = document.createElement('div');
    cell.classList.add('cell');
    cell.dataset.index = index;
    cell.addEventListener('click', () => cellClick1(index));
    board.appendChild(cell);
});
function cellClick1(index) {
    if (cells[index] || checkForWinner()) return;
    cells[index] = currentPlayer;
    renderBoard();
    if (!checkForWinner()) {
        currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    }
}
function renderBoard() {
    cells.forEach((value, index) => {
        board.children[index].textContent = value || '';
    });
}
function checkForWinner() {
    let comb41 = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],
        [0, 3, 6], [1, 4, 7], [2, 5, 8],
        [0, 4, 8], [2, 4, 6]
    ];
    for (let comb of comb41) {
        let [a, b, c] = comb;
        if (cells[a] && cells[a] === cells[b] && cells[a] === cells[c]) {
            alert('Игрок ' +currentPlayer+' победил!');
            return true;
        }
    }
    if (cells.every(cell => cell)) {
        alert('Ничья');
        return true;
    }
    return false;
}

// 47
const colors = ['red', 'green', 'blue'];
let clicks = 0;
const field = document.getElementById('field');
const counter = document.getElementById('clicks');
const cells2 = Array.from({ length: 9 });
cells2.forEach((_, index) => {
    const cell = document.createElement('td');
    cell.addEventListener('click', () => cellClick2(cells2, index));
    field.appendChild(cell);
});
function cellClick2(cells2, index) {
    clicks++;
    counter.textContent = clicks;
    const currentColor = cells2[index]?.classList[1];
    const nextColorIndex = (currentColor ? colors.indexOf(currentColor) + 1 : 0) % colors.length;
    cells2[index].className = colors[nextColorIndex];
    if (win2(cells2)) {
        alert('Победа');
    }
}
function win2(cells2) {
    return cells2.every(cell => cell.classList[1] === cells2[0].classList[1]);
}