//Практика циклы
//1
let i1 = 1;
while (i1 <= 100) {
	console.log(i1);
	i1++;
}

//2
let i2 = 100;
while (i2 >= 1){
    console.log(i2);
    i2--;
}

//3
let i3 = 1;
while (i3 <= 100) {
    if (i3 % 2 == 0){
        console.log(i3);
        i3++;
    } else{
        i3++;
        continue;
    }
}

//4
let arr4 = [];
for(let i4 = 0; i4 < 10; i4++){
    arr4.push("x");
    console.log(arr4[i4]);
}

//5
let arr5 = [];
for(let i5 = 1; i5  <= 10; i5++){
    arr5.push(i5);
}

//6
let arr6 = [0,5,7,9,22,32];
for (let elem6 of arr6){
    if(elem6 > 0 && elem6 < 10){
        console.log(elem6);
    }
}

//7
let arr7 = [0,5,7,9,22,32];
for (let elem7 of arr7){
    if(elem7 == 5){
        console.log('yes');
        break;
    } else {
        continue;
    }
}

//8
let arr8 = [0,5,7,9,22,32];
let res8 = 0;
for (let elem8 of arr8){
    res8 += elem8;
}
console.log(res8);

//9
let arr9 = [0,5,7,9];
let res9 = 0;
for (let elem9 of arr9){
    res9 += elem9*elem9;
}
console.log(res9);

//10
let arr10 = [0,5,7,9];
let res10 = 0;
let i10 = 0;
for (let elem10 of arr10){
    res10 += elem10;
    i10 ++;
}
console.log(res10/i10);

//11
let variable11 = 7;
let res11 = 1;
for (let i11 = 1; i11 < variable11; i11++){
    res11 *= i11+1;
}
console.log(res11);

//12
let arr12 = [];
for(let i12 = 10; i12  >= 1; i12--){
    arr12.push(i12);
}

//13
let arr13 = [0,5,-7,9,22,-32];
let res13 = 0;
for (let elem13 of arr13){
    if (elem13 > 0){
        res13 += elem13;
    } 
}
console.log(res13);

//14
let arr14 = [10, 20, 30, 50, 235, 3000];
for (let elem14 of arr14){
    if (String(elem14)[0] == 1 || String(elem14)[0] == 2 || String(elem14)[0] == 5){
        console.log(elem14);
    }
}

//15
let arr15 = [10, 20, 30, 50, 235, 3000];
for (let i15 = arr15.length; i15 >= 0; i15--){
    console.log(arr15[i15]);
}

//16
let arr16 = [0,2,2,3,5,6,1];
let i16 = 0;
for (let elem16 of arr16){
    if (elem16 == i16){
        console.log(elem16);
        i16++;
    } else {
        i16++;
        continue;
        
    }
}

//17
/*let arr17 = [0,2,2,3,5,6,1];
for(let elem17 of arr17){
    document.write(elem17+'<br>');
}*/

//18
/*let arr18 = [0,2,2,3,5,6,1];
for (let i18 = 0; i18 <= arr18.length-1; i18++) {
document.write(arr18[i18] + '<br>');
}*/

//19
/*let arr19 = ['пн', 'вт', 'ср', 'чт', 'пт', 'сб', 'вс'];
    for(let elem19 of arr19){
        if (elem19 == 'сб' || elem19 == 'вс'){
            document.write('<b>'+elem19+'<b>' + ' ');
        } else {
            document.write(elem19+' ');
        }
    }*/

//20
/*let arr20 = ['пн', 'вт', 'ср', 'чт', 'пт', 'сб', 'вс'];
    let day = 'вс';
    for(let elem20 of arr20){
        if (elem20 == day){
            document.write('<i>'+elem20+'</i>'+' ');
        } else{
            document.write(elem20+' ')
        }
    }*/

//21
let obj21 = {
	employee1: 100,
	employee2: 200,
	employee3: 300,
	employee4: 400,
	employee5: 500,
	employee6: 600,
	employee7: 700,
};
for (let key21 in obj21) {
    console.log(Math.trunc(obj21[key21]*(1.1)));
}

//22
let obj22 = {
	employee1: 100,
	employee2: 200,
	employee3: 300,
	employee4: 400,
	employee5: 500,
	employee6: 600,
	employee7: 700,
};
for (let key22 in obj22) {
    if (obj22[key22] <= 400){
        console.log(Math.trunc(obj22[key22]*(1.1)));
    }
}

//23
let arr23_1 = [1, 2, 3, 4, 5];
let arr23_2 = [6, 7, 8, 9, 10];
let obj23 = {};
for(let i23 = 0; i23 < 5; i23++){
    let key23 = arr23_1[i23];
    let value23 = arr23_2[i23];

    obj23[key23] = value23;
}
console.log(obj23);

//24
let obj24 = {1: 6, 2: 7, 3: 8, 4: 
	9, 5: 10}; 
let keys24 = 0;
let values24 = 0;
for(let key24 in obj24){
    keys24 += parseInt(key24);
    values24 += parseInt(obj24[key24]);
}
console.log(keys24/values24);

//25
let obj25 = {'a': 1, 'b': 2, 'c': 3, 
	'd': 4, 'e': 5}; 
let keys25 = [];
let values25 = [];
for(let key25 in obj25){
    keys25.push(key25);
    values25.push(obj25[key25]);
}
for (let i25 = 0; i25 < 5; i25++){
    console.log(keys25[i25]);
}

//26
let obj26 = {
	1: 125,
	2: 225,
	3: 128,
	4: 356,
	5: 145,
	6: 281,
	7: 452,
};
let arr26 = [];
for (let key26 in obj26){
    if(Math.trunc((obj26[key26])/100) == 1 || Math.trunc((obj26[key26])/100) == 2){
        arr26.push(obj26[key26]);
    }
}

//27
let arr27 = ['a', 'b', 'c', 'd', 'e'];
let obj27 = {};
for(let i27 = 1; i27 < 5; i27++){
    let value27 = arr27[i27];
    obj27[i27] = value27;
}
console.log(obj27);

//28
let arr28 = ['a', 'b', 'c', 'd', 'e'];
let obj28 = {};
for(let i28 = 1; i28 < 5; i28++){
    let key28 = arr28[i28];
    let value28 = i28;
    obj28[key28] = value28;
}
console.log(obj28);