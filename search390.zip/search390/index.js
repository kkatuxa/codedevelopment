//385
let elem385 = document.querySelector('#elem385');
let temp385 = elem385.closest('div');
console.log(temp385);
//385.1
let elem385_1 = document.querySelector('#elem385_1');
let temp385_1 = elem385_1.closest('.www');
console.log(temp385_1);
//386.1
let elem386_1 = document.querySelector('#elem386_1');
let sib386_1 = elem386_1.previousElementSibling;
sib386_1.textContent = sib386_1.textContent + '!';
//386.2
let elem386_2 = document.querySelector('#elem386_2');
let sib386_2 = elem386_2.nextElementSibling;
sib386_2.textContent = sib386_2.textContent + '!';
//386.3
let elem386_3 = document.querySelector('#elem386_3');
let sib386_3 = elem386_3.nextElementSibling.nextElementSibling;
sib386_3.textContent = sib386_3.textContent + '!';
//387
let elem387 = document.getElementById('elem387');
elem387.textContent = '!!!';
//388
let elem388 = document.getElementsByTagName('li');
for(let elem of elem388){
    elem.classList.toggle = 'color';
    elem.style.color = "red";
}
//389
let elem389 = document.getElementsByClassName('www');
for(let elem of elem389){
    elem.classList.toggle = 'color';
    elem.style.color = "red";
}
//390
let parent = document.querySelector('#parent');
let elems1 = parent.querySelectorAll('.aaa');
let elems2 = parent.querySelectorAll('.ggg');
