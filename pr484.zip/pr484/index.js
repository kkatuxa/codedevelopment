//453.1
let elem453_1 = document.querySelector('#elem453_1');
let li453_1 = document.createElement('li');
li453_1.textContent = 'item';
elem453_1.appendChild(li453_1);

//453.2
let elem453_2 = document.querySelector('#elem453_2');
let btn453_2 = document.querySelector('#btn453_2');

btn453_2.addEventListener('click', function(){
    let li453 = document.createElement('li');
    li453.textContent = 'item';
    elem453_2.appendChild(li453);
})

//454
let elem454 = document.querySelector('#elem454');
let btn454 = document.querySelector('#btn454');

btn454.addEventListener('click', function(){
    let temp = document.createElement('li');
    temp.textContent = 'item';
    elem454.appendChild(temp);
    temp.addEventListener('click', function(){
        temp.textContent += '!';
    })
})

//455
let elem455 = document.querySelector('#elem455');
for(let i = 0; i < 10; i++){
    let temp = document.createElement('li');
    temp.textContent = i+1;
    elem455.appendChild(temp);
}

//456
let d456 = document.querySelector('#d456');
let p456 = document.querySelector('#p456');

for(let i = 0; i < 5; i++){
    let temp = document.createElement('input');
   
    temp.addEventListener('blur', function(){
        p456.textContent += temp.value;
    })
     d456.appendChild(temp);
}

//457
let elems457_1 = document.querySelector('#elems457');
let elems457 = elems457_1.children;
for(let elem of elems457){
    elem.addEventListener('click', function(){
        elem.remove();
    })
}

//457.2
let parent457 = document.querySelector('#parent457');
let btn457 = document.querySelector('#btn457');
btn457.addEventListener('click', function(){
    parent457.lastElementChild.remove();
})

//458
let elem458 = document.querySelector('#elem458');
let temp458_1 = document.createElement('li');
let temp458_2 = document.createElement('li');
temp458_1.textContent = 'start';
temp458_2.textContent = 'finish';
elem458.append(temp458_2);
elem458.prepend(temp458_1);

//459
let parent459 = document.querySelector('#parent459');
let elem459 = document.querySelector('#elem459');
let temp459 = document.createElement('li');
temp459.textContent = 'new';
temp459.addEventListener('click', function(){
    temp459.textContent += '!';
})
parent459.insertBefore(temp459, elem459);

//460_1
let elem460_1 = document.querySelector('#elem460_1');
let temp460_1 = document.createElement('p');
temp460_1.textContent = '!!!';

elem460_1.insertAdjacentElement('beforeBegin', temp460_1);

//460_2
let elem460_2 = document.querySelector('#elem460_2');
let temp460_2 = document.createElement('p');
temp460_2.textContent = '!!!';

elem460_2.insertAdjacentElement('afterEnd', temp460_2);

//460_3
let elem460_3 = document.querySelector('#elem460_3');
let temp460_3 = document.createElement('p');
temp460_3.textContent = '!!!';

elem460_3.insertAdjacentElement('afterBegin', temp460_3);

//460_4
let elem460_4 = document.querySelector('#elem460_4');
let temp460_4 = document.createElement('p');
temp460_4.textContent = '!!!';

elem460_4.insertAdjacentElement('beforeEnd', temp460_4);

//461
let elem461 = document.querySelector('#elem461');
elem461.insertAdjacentHTML('beforeBegin', '<div class="www"><p>text</p><p>text</p><input></div>');

//462
let inp462 = document.querySelector('#inp462');
let btn462 = document.querySelector('#btn462');
let d462 = document.querySelector('#d462');

btn462.addEventListener('click', function(){
    let clone = inp462.cloneNode(true);
    d462.appendChild(clone);
})

//463
let elem462 = document.querySelector('#elem463');
console.log(elem463.matches('div.www'))

//464
let parent464 = document.querySelector('#parent464');

let arr464 = [1, 2, 3, 4, 5];

for (let elem of arr464) {
	let p = document.createElement('p');
	p.textContent = elem;
    p.addEventListener('click', function(){
        p.textContent += '!';
    })
	parent464.appendChild(p);
}

//465.1
let elem465_1 = document.querySelector('#elem465_1');
let arr465_1 = [1,2,3,4,5];
function fucn465(){
    console.log(this.textContent);
    this.textContent += '!';
    this.removeEventListener('click', fucn465);
}
for(let elem of arr465_1){
    let temp = document.createElement('li');
    temp.textContent = elem;
    temp.addEventListener('click', fucn465);
    elem465_1.appendChild(temp);
}

//466
let table466 = document.querySelector('#table466');

for(let i = 0; i < 10; i++){
    let tr = document.createElement('tr');

    for(let j = 0; j < 5; j++){
        let td = document.createElement('td');
        td.textContent = 'x';
        tr.appendChild(td);
    }

    table466.appendChild(tr);
}

