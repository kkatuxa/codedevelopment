//168.1 
let arr168 = [ 
    ['a', 'b', 'c'], 
    ['d', 'e', 'f'], 
    ['g', 'h', 'i'], 
    ['j', 'k', 'l'], 
   ]; 
   console.log(arr168[3][2], arr168[1][1], arr168[2][0], arr168[0][0]); 
   let arr168_1 = [[1, 2], [3, 4], [5, 6]]; 
   console.log(arr168_1[0][0]+arr168_1[0][1]+arr168_1[1][0]+arr168_1[1][1]+arr168_1[2][0]+arr168_1[2][1]); 
   //169 
   let arr169 = [ 
    [ 
     [1, 2], 
     [3, 4], 
    ], 
    [ 
     [5, 6], 
     [7, 8], 
    ], 
   ]; 
   console.log(arr169[0][0][0]+arr169[0][0][1]+arr169[0][1][0]+arr169[0][1][1]+arr169[1][0][0]+arr169[1][0][1]+arr169[1][1][0]+arr169[1][1][1]); 
   //170 
   let arr170 = [[1, 2, 3, [4, 5, [6, 7]]], [8, [9, 10]]]; 
   console.log(arr170[0][0]+arr170[0][1]+arr170[0][2]+arr170[0][3][0]+arr170[0][3][1]+arr170[0][3][2][0]+arr170[0][3][2][1]+arr170[1][0]+arr170[1][1][0]+arr170[1][1][1]); 
   //171 
   let arr171 = [[1, 2, 3], [4, 5], [6]]; 
   res171 = 0; 
   for (let subarr171 of arr171){ 
       for(let elem171 of subarr171){ 
           res171 += elem171; 
       } 
   } 
   console.log(res171); 
   let arr171_1 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]]; 
   res171_1 = 0; 
   for(let subarr171_1 of arr171_1){ 
       for(let subarr171_1_1 of subarr171_1){ 
           for(let elem171_1 of subarr171_1_1){ 
               res171_1 += elem171_1; 
           } 
       } 
   } 
   console.log(res171_1); 
   //172 
   let res172 = 0; 
   for (let i = 0; i < arr171.length; i++){ 
       for(let j = 0; j < arr171.length; j++){ 
           res172 += arr171[i][j]; 
       } 
   } 
   //173 
   let arr173 = []; 
   for (let i = 0; i < 3; i++){ 
       arr173[i] = []; 
       for(let j = 0; j < 5; j++){ 
           arr173[i].push(j + 1); 
           console.log(arr173[i][j]); 
       } 
   } 
   let arr173_1 = []; 
   for (let i = 0;i < 3;i++){ 
       arr173_1[i] = []; 
       for (let j = 0;j < 4; j++){ 
           arr173_1[i].push('x'); 
           console.log(arr173_1[i][j]); 
       } 
   } 
   let arr173_2 = []; 
   for(let i = 0; i <3; i++){ 
       arr173_2[i] = []; 
       for(let j = 0;j < 2; j++){ 
           arr173_2[i][j] = []; 
           for(let k = 0; k < 5; k++){ 
               arr173_2[i][j].push(k+1); 
               console.log(arr173_2[i][j][k]); 
           } 
       } 
   } 
    
   //175 
   let arr175 = []; 
   for(let i = 0, k = 1; i < 4; i++){ 
       arr175[i] = []; 
       for(let j = 0;j < 2; j++){ 
           arr175[i].push(k++); 
           console.log(arr175[i][j]); 
       } 
   } 
   let arr175_1 = []; 
   let k = 2; 
   for(let i = 0; i < 4; i++){ 
       arr175_1[i] = []; 
       for(let j = 0;j < 3; j++){ 
           arr175_1[i].push(k); 
           k += 2; 
           console.log(arr175_1[i][j]); 
       } 
   } 
   let arr175_2 = []; 
   let n = 1; 
   for (let i = 0; i < 2; i++){ 
       arr175_2[i] = []; 
       for (let j = 0; j < 2; j++){ 
           arr175_2[i][j] = []; 
           for (let k = 0; k < 2; k++){ 
               arr175_2[i][j].push(n); 
               n++; 
               console.log(arr175_2[i][j][k]); 
           } 
       } 
   } 
    
   //176 
   let obj176 = { 
    key1: { 
     key1: 1, 
     key2: 2, 
     key3: 3, 
    }, 
    key2: { 
     key1: 4, 
     key2: 5, 
     key3: 6, 
    }, 
    key3: { 
     key1: 7, 
     key2: 8, 
     key3: 9, 
    }, 
   } 
   console.log(obj176.key1.key1+obj176.key1.key2 + obj176.key1.key3 + obj176.key2.key1 + obj176.key2.key2 + obj176.key2.key3 + obj176.key3.key1 + obj176.key3.key2 +obj176.key3.key3); 
   let obj176_1 = { 
    1: { 
     1: 'a1', 
     2: 'a2', 
     3: 'a3', 
    }, 
    2: { 
     1: 'b1', 
     2: 'b2', 
     3: 'b3', 
    }, 
    3: { 
     1: 'c1', 
     2: 'c2', 
     3: 'c3', 
    }, 
   } 
   console.log(obj176_1['2']['1'] + obj176_1['3']['1']); 
   let obj176_2 = { 
    key1: { 
     a: 1, b: 2, c: { 
      d: 3, 
      e: 4, 
     }, f: 5, 
    }, 
    key2: { 
     g: 6, h: 7, 
    }, 
   } 
   console.log(obj176_2.key1.a +obj176_2.key1.b + obj176_2.key1.c.d + obj176_2.key1.c.e + obj176_2.key1.f + obj176_2.key2.g + obj176_2.key2.h); 
   //177 
   let obj177 = { 
    1: { 
     1: 11, 
     2: 12, 
     3: 13, 
    }, 
    2: { 
     1: 21, 
     2: 22, 
     3: 23, 
    }, 
    3: { 
     1: 24, 
     2: 25, 
     3: 26, 
    }, 
   } 
   let res177 = 0; 
   for (let key177 in obj177){ 
       let subobj177 = obj177[key177]; 
       for(let subkey177 in subobj177){ 
           res177 +=subobj177[subkey177]; 
       } 
   } 
   console.log(res177);
   //178
   let students178 = {
	'group1': ['name11', 'name12', 
		'name13'], 
	'group2': ['name21', 'name22', 
		'name23'], 
	'group3': ['name31', 'name32', 
		'name33'], 
};
console.log(students178['group1'][0]);
//179
let data179 = {
	1: [
		'data11',
		'data12',
		'data13',
	],
	2: [
		'data21',
		'data22',
		'data23',
	],
	3: [
		'data31',
		'data32',
		'data33',
	],
	4: [
		'data41',
		'data42',
		'data43',
	],
};
for(let group179 in data179){
    for(let dates179 of data179[group179]){
        console.log(dates179);
    }
}
let data179_1 = [
	{
		1: 'data11',
		2: 'data12',
		3: 'data13',
	},
	{
		1: 'data21',
		2: 'data22',
		3: 'data33',
	},
	{
		1: 'data31',
		2: 'data32',
		3: 'data33',
	},
];
for(let group179_1 in data179_1){
        console.log(data179_1[group179_1]);
}
//180
let employees180 = [
	{
		name: 'name1',
		salary: 300,
	},
	{
		name: 'name2',
		salary: 400,
	},
	{
		name: 'name3',
		salary: 500,
	},
];
for(let user of employees180){
    console.log(user.name + ' - ' + user.salary)
}
let employees180_1 = [
	{
		name: 'name1',
		salary: 300,
	},
	{
		name: 'name2',
		salary: 400,
	},
	{
		name: 'name3',
		salary: 500,
	},
];
res180_1 = 0;
for (let user of employees180_1){
    res180_1 += user.salary;
}
console.log(res180_1);

let employees180_2 = [
	{
		name: 'name1',
		salary: 300,
		age: 28,
	},
	{
		name: 'name2',
		salary: 400,
		age: 29,
	},
	{
		name: 'name3',
		salary: 500,
		age: 30,
	},
	{
		name: 'name4',
		salary: 600,
		age: 31,
	},
	{
		name: 'name5',
		salary: 700,
		age: 32,
	},
];
res180_2 = 0;
for(let user of employees180_2){
    if (user.age >= 30){
        res180_2 += user.salary;
    }
}
console.log(res180_2);
//181
let months181 = {
	'ru': [
		'январь',
		'февраль',
		'март',
		'апрель',
		'май',
		'июнь',
		'июль',
		'август',
		'сентябрь',
		'октябрь',
		'ноябрь',
		'декабрь',
	],
	'en': [
		'january',
		'february',
		'march',
		'april',
		'may',
		'june',
		'july',
		'august',
		'september',
		'october',
		'november',
		'december',
	],
};
let lang181 = 'ru';
let month181 = 5;
console.log(months181[lang181][month181-1]);

let affairs181 = {
	'2018': {
		11: {
			29: ['дело111', 'дело112', 'дело113'],
			30: ['дело121', 'дело122', 'дело123'],
		},
		12: {
			30: ['дело211', 'дело212', 'дело213'],
			31: ['дело221', 'дело222', 'дело223'],
		},
	},
	'2019': {
		12: {
			29: ['дело311', 'дело312', 'дело313'],
			30: ['дело321', 'дело322', 'дело323'],
			31: ['дело331', 'дело332', 'дело333'],
		}
	},
}
let year181_1 = 2018;
let day181_1 = 30;
let month181_1 = 12;
console.log(affairs181[year181_1][month181_1][day181_1])
//182
let employees182 = [
	{
		name: 'name1',
		salary: 300,
		age: 28,
	},
	{
		name: 'name2',
		salary: 400,
		age: 29,
	},
	{
		name: 'name3',
		salary: 500,
		age: 30,
	},
];
employees182.push(
    {
        name: 'name4',
		salary: 500,
		age: 31,
    }
)
//183
let affairs184 = {
	'2019-12-28': ['data11', 'data12', 
		'data13'], 
	'2019-12-29': ['data21', 'data22', 
		'data23'], 
	'2019-12-30': ['data31', 'data32', 
		'data33'], 
}
affairs184["2019-12-29"].push('data24');
affairs184["2019-12-32"] = [];
affairs184["2019-12-32"].push('data41');
affairs184["2019-12-32"].push('data42');

let students183 = {
	'group1': {
		'subgroup11': ['student111', 'student112', 
			'student113'], 
		'subgroup12': ['student121', 'student122', 
			'student123'], 
	},
	'group2': {
		'subgroup21': ['student211', 'student212', 
			'student213'], 
		'subgroup22': ['student221', 'student222', 
			'student223'], 
	},
	'group3': {
		'subgroup31': ['student311', 'student312', 
			'student313'], 
		'subgroup32': ['student321', 'student322', 
			'student323'], 
	},
};
students183['group1']['subgroup11'].push('student114');
students183['group1']['subgroup13'] = [];
students183['group4'] = [];
students183['group4']['subgroup41'] = [];
students183['group4']['subgroup41'].push('student411');
students183['group4']['subgroup41'].push('student412');
