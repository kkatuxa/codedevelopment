//184
console.log(2**10);
console.log(Math.sqrt(245));
let arr184 = [4, 2, 5, 19, 13, 0, 10];
let sum184 = 0;
for(let elem of arr184){
    sum184 += elem;
}
console.log(Math.sqrt(sum184));
//185
let num185 = Math.sqrt(379);
console.log(Math.round(num185));
console.log(num185.toFixed(1));
console.log(num185.toFixed(2));

let num185_1 = Math.sqrt(587);
let obj185 = {};
let x185 = Math.ceil(num185_1);
let y185 = Math.floor(num185_1);
obj185.floor = y185;
obj185.ceil = x185;

//186
console.log(Math.min(4, -2, 5, 19, -130, 0, 10));
console.log(Math.max(4, -2, 5, 19, -130, 0, 10));

//187
function getRandomArbitary(min, max) {
	return Math.random() * (max - min) 
		+ min; 
}

console.log(getRandomArbitary(1,100));

function getRandomInt(min, max) {
	return Math.floor(Math.random() * (max - min 
		+ 1)) + min; 
}

let arr187 = [];
for(let i = 0; i <= 10; i++){
    arr187[i] = getRandomInt(1,100);
    console.log(arr187[i]);
}

//188
let a188 = 3;
let b188 = 10;
console.log(Math.abs(a188-b188));

//189
let str189 = 'js';
console.log(str189.toUpperCase());
let str189_1 = 'JS';
console.log(str189_1.toLowerCase());

//190
let str190 = 'я учу javascript!';
console.log(str190.substr(6));
console.log(str190.substring(2,5));
console.log(str190.slice(2,6));

//191
let str191 = 'http://03494';
console.log(str191.startsWith('http://'));
console.log(str191.endsWith('.html'));

//192
let str192 = '1-2-3-4-5';
while(str192.includes('-')){
    str192 = str192.replace('-','.');
}
console.log(str192);

//193
let str193 = '1-2-3-4-5';
let arr193 = str193.split('-'); 
let str193_1 = '12345';
let arr193_1 = str193_1.split('');
let arr193_2 = [1, 2, 3, 4, 5];
let str193_2 = arr193_2.join('-');
console.log(str193_2);

//194
let arr194 = [1, 2, 3];
console.log(arr194.shift());
console.log(arr194.pop());
arr194.push(4,5,6);
arr194.unshift(4,5,6);

//195
let arr195 = [1, 2, 3, 4, 5];
console.log(arr195.slice(0,3));
let arr195_1 = arr195.slice(3,5);
console.log(arr195_1);

//196
let arr196 = [1, 2, 3, 4, 5];
arr196.splice(1,2);
console.log(arr196);
let arr196_1 = [1, 2, 3, 4, 5];
arr196_1.splice(3,0,'a','b','c');
console.log(arr196_1);
let arr196_2 = [1, 2, 3, 4, 5];
arr196_2.splice(1,0,'a','b');
arr196_2.splice(6,0,'c');
arr196_2.splice(8,0,'e');
console.log(arr196_2);

//197
let arr197 = [1, 2, 3, 4, 5];
console.log(arr197.includes(3));

//198
let obj198 = {a: 1, b: 2, c: 3};
let keys198 = Object.keys(obj198);
console.log(keys198);

//199
let num1 = 12345;
let arr1 = String(num1).split('');

let sum1 = 0;
for (let digit of arr1) {
	sum1 += Number(digit);
}

console.log(sum1);

let num2 = 12345;
let arr2 = String(num2).split('');

let sum2 = 0;
for (let digit of arr2) {
	sum2 += Number(digit);
}

console.log(sum2);

let num3 = 12345;
let arr3 = String(num3).split('');

let sum3 = 0;
for (let digit of arr3) {
	sum3 += Number(digit);
}

console.log(sum3);

let num4 = 12345;
let arr4 = String(num4).split('');

let sum4 = 0;
for (let digit of arr4) {
	sum4 += Number(digit);
}

console.log(sum4);

let num = 12345;
let arr = String(num).split('');

let prod = 1;
for (let digit of arr) {
	prod *= digit;
}

console.log(prod);