//414
let btn414 = document.querySelector('#btn414');
btn414.addEventListener('click', function(){
    console.log(event);
})
//415
let delem415 = document.querySelector('#delem415');
let pelem415 = document.querySelector('#pelem415');
document.addEventListener('mousemove', function(event){
    pelem415.innerHTML = event.clientX + ':' + event.clientY;
})
//416
let elem416 = document.querySelector('#elem416');

elem416.addEventListener('click', func416);
elem416.addEventListener('dblclick', func416);

function func416(event) {
	if (event.type == 'click'){
        elem416.classList.add = 'color';
        elem416.style.color = 'green';
    } else if (event.type == 'dblclick'){
        elem416.classList.add = 'color';
        elem416.style.color = 'red';
    }
}
//417
let elem417 = document.querySelector('#elem417');
elem417.addEventListener('click', function(event){
    if (event.target.tagName == 'LI'){
        event.target.textContent += '!';
    } else if(event.target.tagName == 'UL'){
        console.log('ну жесть');
    }
})
//418.1
let inp418_1 = document.querySelector('#inp418_1');
let pelem418_1 = document.querySelector('#pelem418_1');
inp418_1.addEventListener('keypress', function(event){
    pelem418_1.textContent += event.key + ' - ' + event.code + ' ';
})
//419.1
let pelem419 = document.querySelector('#pelem419');
pelem419.addEventListener('click', function(event){
    if (event.altKey){
        pelem419.style.color = 'red';
    }
})
//419.2
let elem419 = document.querySelector('#elem419');
elem419.addEventListener('click', function(event){
    if (event.target.tagName == 'LI'){
        if(event.ctrlKey){
            event.target.textContent += '1';
        } else if (event.shiftKey){
            event.target.textContent += '2';
        }
    }
})
//420.1
let aelem420_1 = document.querySelector('#elem420_1');
aelem420_1.addEventListener('click', function(event){
    event.preventDefault();
    event.target.textContent += aelem420_1.href;
})
//420.2
let inp420_1 = document.querySelector('#inp420_1');
let inp420_2 = document.querySelector('#inp420_2');
let pelem420 = document.querySelector('#pelem420');
let aelem420_2 = document.querySelector('#elem420_2');
aelem420_2.addEventListener('click', function(event){
    event.preventDefault();
    pelem420.textContent = Number(inp420_1.value) + Number(inp420_2.value);
})
//421.1
let elem421_1 = document.querySelector('#elem421_1');
let elem421_2 = document.querySelector('#elem421_2');
let elem421_3 = document.querySelector('#elem421_3');
elem421_1.addEventListener('click', function(){
    alert('fsper');
})
elem421_2.addEventListener('click', function(){
    alert('fspefgjghr');
})
elem421_3.addEventListener('click', function(){
    alert('fsfgjhgjhgjkkjper');
})

//422
let delem422 = document.querySelector('.delem422');
delem422.addEventListener('click', function(event){
    if (event.target.matches('ul')){
        console.log('ul');
    } else if (event.target.matches('li')){
        event.target.textContent += '!';
    } else if(event.target.matches('div')){
        console.log('div');
    }
})