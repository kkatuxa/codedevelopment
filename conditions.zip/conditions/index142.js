//104

let test_104 = 0;
if (test_104 > 10) {
    console.log('+++');
} else {
    console.log('---');
}

if (test_104 < 10) {
    console.log('+++');
} else {
    console.log('---');
}

if (test_104 >= 10) {
    console.log('+++');
} else {
    console.log('---');
}

if (test_104 <= 10) {
    console.log('+++');
} else {
    console.log('---');
}

//106

let test106 = 1;
if (test106 == 10) {
	console.log('+++');
} else {
	console.log('---'); 
}

//107

let test_107 = 0;
if (test_107 != 10) {
	console.log('+++');
} else {
	console.log('---'); 
}

//108

let test1_108 = 1;
let test2_108 = 2;
if (test2_108 > test1_108) {
	console.log('Переменная test2 является наибольшей'); 
} else {
	console.log('Переменная test1 является наибольшей');
}
if (test2_108 == test1_108) {
	console.log('Переменные test1 и test2 равны'); 
} else {
	console.log('Переменные test1 и test2 не являются равными');
}

//109

let test1_109 = 'abs';
let test2_109 = 'sba';
if (test1_109 == test2_109) {
	console.log('+++'); 
} else {
	console.log('---');
}

//110

let test1_110 = '123';
let test2_110 = 123;
if (test1_110 == test2_110) {
	console.log('+++'); 
} else {
	console.log('---');
}

//113

let num_113 = 3;

if (num_113 > 0 && num_113 < 5) {
	console.log('+++');
} else {
	console.log('---');
}
if (num_113 >= 10 && num_113 <= 20) {
	console.log('+++');
} else {
	console.log('---');
}
let num1_113 = 2;
let num2_113 = 3;
if (num1_113 <= 1 && num2_113 >= 3) {
	console.log('+++');
} else {
	console.log('---');
}

//117

let num1_117 = -2;
let num2_117 = 13;
if (!(num1_117 >= 0 || num2_117 <= 10)) {
	console.log('+++');
} else {
	console.log('---');
}

//118

let test118 = true;
if (test118 == true) {
    console.log('+++');
} else {
    console.log('---');
}
if (test118 == false) {
    console.log('+++');
} else {
    console.log('---');
}

//120

let test_120 = true;

if (test_120) {
	console.log('+++');
} else {
	console.log('---');
}

//121
let test_121 = true;
if (!test_121) {
	console.log('+++');
} else {
	console.log('---');
}

if (!test_121) {
	console.log('+++');
} else {
	console.log('---');
}

if (test_121) {
	console.log('+++');
} else {
	console.log('---');
}

//123

let test1_123 = true;
let test2_123 = true;
let test3_123 = true;

if (test1_123 && test2_123) {
	console.log('+++');
} else {
	console.log('---');
}

if (test1_123 && !test2_123) {
	console.log('+++');
} else {
	console.log('---');
}

if (!test1_123 && !test2_123) {
	console.log('+++');
} else {
	console.log('---');
}

if (test1_123 && test2_123) {
	console.log('+++');
} else {
	console.log('---');
}

if (test1_123 && test2_123 && test3_123) { 
	console.log('+++');
} else {
	console.log('---');
}

if (test1_123 || test2_123 && test3_123) { 
	console.log('+++');
} else {
	console.log('---');
}

if (test1_123 || !test2_123 && !test3_123) { 
	console.log('+++');
} else {
	console.log('---');
}

//124

let test124 = 10;

if (test124 == 10) {
	console.log('yes');
}

//125

let test125 = 0;
if (test125 > 0) console.log('+++'); else console.log('---');
if (test125 > 0) console.log('+++');

//127

let day127 = 34;
if (day127 <= 10) {
    console.log('1');
} else if (day127 >= 11 && day127 <= 20) {
    console.log('2');
} else if (day127 >= 21 && day127 <= 31) {
    console.log('3');
} else {
    console.log('Ошибка')
}

//128

let num128 = 55;
if (num128 >= 10 && num128 <= 99) {
    if(console.log(num128%10+parseInt(num128/10)) <=9 ){
        console.log ('Полученная сумма однозначна');
    } else {
        console.log('Полученная сумма двузначна');
    }
}

//129 

let lang129 = 'de';
switch (lang129) {
    case "ru":
        console.log('рус');
    break;
    case 'en':
        console.log('анг');
    break;
    case 'de':
        console.log('нем');
    break;
    default:
        console.log('язык не поддерживается');
}

//131

let num131 = 1;
let res131 = num131 >= 0 ? '1':'2';
console.log(res131);

//132

let a1_132 = 2 * (3 - 1);
let b1_132 = 6 - 2;
console.log(result1_132 = a1_132 == b1_132)

let a2_132 = 5 * (7 - 4);
let b2_132 = 1 + 2 + 7;
console.log(result2_132 = a2_132 > b2_132);

let a3_132 = 2 ** 4;
let b3_132 = 4 ** 2;
console.log(result3_132 = a3_132 != b3_132)

//136

/*let ok = confirm('Вам есть 18?');
if (ok) {
    alert('текст для взрослых');
} else {
    alert('доступ запрещен');
}*/

//134
let age134 = 19;
let adult134 = true;
if (age134 >= 18) {
	let adult134 = true;
} else {
	let adult134 = false;
}
console.log(adult134);

//142 Практика на условия
//1
let month142 = 6;
if ((month142 >= 1 && month142 <= 2) || month142 == 12){
    console.log('Зима');
} else if (month142 >= 3 && month142 <= 5) {
    console.log('Весна');
} else if (month142 >= 6 && month142 <= 8) {
    console.log('Лето');
} else if(month142 >= 9 && month142 <= 11) {
    console.log('Осень');
}
//2
let string142 = 'abcde';
if (string142[0] == 'a'){
    console.log ('yes');
} else {
    console.log('no');
}
//3
let number142 = 32345;
if (String(number142)[0] == '1' || String(number142)[0] == '2' || String(number142)[0] == '3'){
    console.log('yes');
} else {
    console.log('no');
}
//4
let num142 = 333;
console.log(Math.trunc(num142/100) + Math.trunc(num142/10)%10 + num142%10);
//5
let num142_1 = 123322;
let num142_2 = Math.trunc((num142_1 % 1000)/100) + Math.trunc((num142_1 % 100) / 10) + num142_1 % 10;
let num142_3 = Math.trunc(Math.trunc(num142_1 / 1000)/100) + Math.trunc(Math.trunc(num142_1 / 1000)/10)%10 + Math.trunc(num142_1 / 1000) % 10;
if (num142_2 == num142_3) {
    console.log('yes');
} else {
    console.log('no');
}