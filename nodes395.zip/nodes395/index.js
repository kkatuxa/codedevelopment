//392
let elem392 = document.querySelector('#elem392');
let arr392 = elem392.childNodes;
for(let elem of arr392){
    console.log(elem);
}
//393
let elem393 = document.querySelector('#elem393');
let arr393 = elem393.childNodes;
for(let elem of arr393){
    console.log(elem.nodeName);
}
//394
let elem394 = document.querySelector('#elem394');
let arr394 = elem394.childNodes;
for(let elem of arr394){
    console.log(elem.nodeType);
}
//395
let elem395 = document.querySelector('#elem395');
let arr395 = elem395.childNodes;
for(let elem of arr395){
    if (elem.nodeType == 3){
        console.log(elem.textContent);
    } else if (elem.nodeType == 1 || elem.nodeType == 3){
        console.log(elem.nodeValue);
    }
}