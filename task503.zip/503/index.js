//485 
function setAttr(sel485, name, newName) {
    let elem485 = document.querySelector(sel485);
    elem485.setAttribute(name, newName);
}
setAttr('.elem485', 'class', 'highlight');

//486
function setText(selector486, text486) {
	let elems486 = document.querySelectorAll(selector486);
	
	for (let elem486 of elems486) {
		elem486.textContent = text486;
	}
}
setText('.elem486', 'привет');

//487
forEach('.elem487', function(elem487) {
	elem487.textContent += '!';
});

function forEach(selector487, func487) {
	let elems487 = document.querySelectorAll(selector487);
	
	for (let elem487 of elems487) {
		func487(elem487);
	}
}

//488 
forEach('.elem487', function(elem488, index488) {
	elem488.textContent = index488 + elem488.textContent;
});
function forEach(selector488, func488) {
	let elems488 = document.querySelectorAll(selector488);
	for (let i488 = 0; i488 < elems488.length; i488++) {
		func488(elems488[i488], i488);
	}
}

//489 
function appendText489(elem489, text489){
	elem489.textContent += text489 + '!';
}
// 
let elem489_1 = document.getElementById('elem489_1');
appendText489(elem489_1, 'text1');
let elem489_2 = document.getElementById('elem489_2');
appendText489(elem489_2, 'text2');

//490 
function appendText490(elems490, text490) {
	for (let elem490 of elems490) {
		elem490.textContent = text490;
	}
}
let elems490 = document.querySelectorAll('.elem490');
appendText490(elems490, 'text');
//
function appendElem(elem490_1, text) {
    let li_elem490_1 = document.createElement('li');
    li_elem490_1.textContent = text;
    elem490_1.appendChild(li_elem490_1);
}
let elem49_01 = document.querySelector('#elem490_1');
appendElem(elem490_1, 'new new');

//491 
function createTable(rows491, cols491, res491) {
    let table491 = document.createElement('table');
    for (let i491 = 0; i491 < rows491; i491++) {
        let row491 = table491.insertRow();
        for (let j491 = 0; j491 < cols491; j491++) {
            let cell491 = row491.insertCell();
            cell491.textContent = i491 + 1 - j491 + 1;
        }
    }
    res491.appendChild(table491);
}
let div1 = document.querySelector('#elem491_2');
createTable(4, 3, div1);

//497
// let sum;
// let but497 = document.getElementById('button497');
// let input1 = document.getElementById('elem497');
// let input2 = document.getElementById('input497_1');
// let input3 = document.getElementById('input497_2');
// but497.addEventListener('click', function() {
//     let num1 = Number(input1.value);
//     let num2 = Number(input2.value);
//     let num3 = Number(input3.value);
//     let result = sum(num1, num2, num3);
//     console.log(result);
// });

//501 
;(function() {
	let str1 = 'переменная модуля';
	let str2 = 'переменная модуля';
	let str3 = 'переменная модуля';
	
	function func1() {
		alert('функция модуля');
	}
	function func2() {
		alert('функция модуля');
	}
	function func3() {
		alert('функция модуля');
	}
    window.func = str1;
    window.func = func1;
    window.func = func2;
})();

//502 
;(function() {
	let str1 = 'переменная модуля';
	let str2 = 'переменная модуля';
	let str3 = 'переменная модуля';
	function func1() {
		alert('функция модуля');
	}
	function func2() {
		alert('функция модуля');
	}
	function func3() {
		alert('функция модуля');
	}
	function func4() {
		alert('функция модуля');
	}
	function func5() {
		alert('функция модуля');
	}
    window.module = {str1,str2};
    window.module = module;
})();



