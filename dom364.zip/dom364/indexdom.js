//Практикум введение в DOM
//1
let inp1 = document.querySelector('#inp1');
let p1 = document.querySelector('#p1');
inp1.addEventListener('blur', function(){
    p1.textContent += inp1.value;
})

//2
let inp2_1 = document.querySelector('#inp2_1');
let inp2_2 = document.querySelector('#inp2_2');
let inp2_3 = document.querySelector('#inp2_3');
let p2 = document.querySelector('#p2');
let btn2 = document.querySelector('#btn2');
btn2.addEventListener('click', function(){
    p2.textContent = Number(inp2_1.value) + Number(inp2_2.value) + Number(inp2_3.value);
})

//3
let inp3 = document.querySelector('#inp3');
let p3 = document.querySelector('#p3');
inp3.addEventListener('blur', function(){
    let sum = 0;
    let temp = inp3.value;
    while(temp > 0){
        sum += temp % 10;
        temp = Math.trunc(temp / 10);
    }
    p3.textContent = sum;
})

//4
let inp4 = document.querySelector('#inp4');
inp4.addEventListener('blur', function(){
    let temp = inp4.value.split(',');
    let count = 0;
    let sum = 0;
    for (let i = 0; i < temp.length; i++){
        sum += Number(temp[i]);
        count++;
    }
    inp4.value = sum / count;
})

//5
let inp5_1 = document.querySelector('#inp5_1');
let inp5_2 = document.querySelector('#inp5_2');
let inp5_3 = document.querySelector('#inp5_3');
let inp5_4 = document.querySelector('#inp5_4');
inp5_1.addEventListener('blur', function(){
    let temp = inp5_1.value.split(" ");
    inp5_2.value = temp[0];
    inp5_3.value = temp[1];
    inp5_4.value = temp[2];
})

//6
let inp6 = document.querySelector('#inp6');
inp6.addEventListener('blur', function(){
    let temp = inp6.value.split(" ");
    for(let i = 0; i < temp.length; i++){
        let temp1 = temp[i].split('');
        temp1[0] = temp1[0].toUpperCase();
        temp[i] = temp1.join('');
    }
    inp6.value = temp.join(' ');
})

//7
let inp7 = document.querySelector('#inp7');
inp7.addEventListener('blur', function(){
    let temp = inp7.value.split(" ");
    let count = 0;
    for(let i = 0; i < temp.length; i++){
        count++;
    }
    inp7.value = 'Количество слов ' + count;
})

//8
let inp8 = document.querySelector('#inp8');
inp8.addEventListener('blur', function(){
    let temp = inp8.value.split('.');
    inp8.value = temp.reverse().join('-');
})

//9
let inp9 = document.querySelector('#inp9');
let btn9 = document.querySelector('#btn9');
btn9.addEventListener('click', function(){
    let temp = inp9.value.split('').reverse().join('');
    if (temp == inp9.value){
        inp9.value = 'true';
    } else{
        inp9.value = 'false';
    }
})

//10
let inp10 = document.querySelector('#inp10');
inp10.addEventListener('blur', function(){
    let temp = inp10.value.split('');
    let flag = false;
    for(let i = 0; i < temp.length; i++){
        if (Number(temp[i]) == 3){
            flag = true;
        } 
    }
    inp10.value = flag;
})

//11
let p11_1 = document.querySelector('#p11_1');
let p11_2 = document.querySelector('#p11_2');
let btn11 = document.querySelector('#btn11');
btn11.addEventListener('click', function(){
    p11_1.textContent += '1';
    p11_2.textContent += '2';
})

//12
let a12_1 = document.querySelector('#a12_1');
let a12_2 = document.querySelector('#a12_2');
let a12_3 = document.querySelector('#a12_3');
let btn12 = document.querySelector('#btn12');
btn12.addEventListener('click', function(){
    a12_1.innerHTML = a12_1.innerHTML + '(' + a12_1.href + ')';
    a12_2.innerHTML = a12_2.innerHTML + '(' + a12_2.href + ')';
    a12_3.innerHTML = a12_3.innerHTML + '(' + a12_3.href + ')';
})

//13
let a13_1 = document.querySelector('#a13_1');
let a13_2 = document.querySelector('#a13_2');
let btn13 = document.querySelector('#btn13');
btn13.addEventListener('click', function(){
    if (a13_1.href.startsWith('http://')){
        a13_1.innerHTML = a13_1.href + '&rarr';
    }
})

//14
let inp14 = document.querySelectorAll('.inp14');
for(let elem of inp14){
    elem.addEventListener('focus', function(){
        elem.value = elem.value**2;
    })
}

//15
let inp15 = document.querySelector('.inp15');
inp15.addEventListener('blur', function(){
    let days = ['вс', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб'];
    let temp = inp15.value.split('.');
    let date = new Date(temp[2], temp[1], temp[0]);
    let temp1 = date.getDay();
    inp15.value = days[temp1];
})

//16
let inp16 = document.querySelector('.inp16');
let btn16p = document.querySelector('#btn16plus');
let btn16m = document.querySelector('#btn16minus');
btn16p.addEventListener('click', function(){
    inp16.value = Number(inp16.value) + 1;
})
btn16m.addEventListener('click', function(){
    if (Number(inp16.value) != 0){
        inp16.value = Number(inp16.value) - 1;
    }
})

//17
let inp17 = document.querySelector('.inp17');
let p17 = document.querySelectorAll('.p17');
for(let elem of p17){
    elem.addEventListener('click', function(){
        inp17.value = Number(inp17.value) + 1;
    })
}

//18
let btn18 = document.querySelector('#btn18');
let d18 = document.querySelectorAll('.div18');
for(let elem of d18){
    btn18.addEventListener('click', function(){
        let temp;
        if (elem.textContent.length > 10){
            temp = elem.textContent.slice(0,10);
            elem.textContent = temp + '...';
        }
        
    })
}

//19
let btn19  = document.querySelector('#btn19');
let inp19 = document.querySelector('.inp19');
btn19.addEventListener('click', function(){
    let chrs = 'abdehkmnpswxzABDEFGHKMNPQRSTWXZ123456789';
        let str = '';
        for (let i = 0; i < 9; i++) {
            let pos = Math.floor(Math.random() * chrs.length);
            str += chrs.substring(pos,pos+1);
        }
        inp19.value = str;
})

//20
let btn20  = document.querySelector('#btn20');
let inp20 = document.querySelector('.inp20');
btn20.addEventListener('click', function(){
    let word_spl = inp20.value.split('');
    for (let i = word_spl.length - 1; i > 0; i--) {
      let j = Math.floor(Math.random() * (i + 1));
      [word_spl[i], word_spl[j]] = [word_spl[j], word_spl[i]];
    }
    inp20.value = word_spl.join("");
})

//21
let inp21 = document.querySelector('#inp21');
let btn21 = document.querySelector('#btn21');
let p21 = document.querySelector('#p21');
btn21.addEventListener('click', function(){
    let temp = (inp21.value - 32) * (5/9);
    p21.textContent = temp;
})

//22
let inp22 = document.querySelector('#inp22');
let btn22 = document.querySelector('#btn22');
let p22 = document.querySelector('#p22');
btn22.addEventListener('click', function(){
    let temp = inp22.value;
    function factorial(x) {
        if (x === 0) {
          return 1;
       }
        return x * factorial(x-1);  
      }
    temp1 = factorial(Number(temp));
    p22.textContent = temp1;
})

//23
let inp23_1 = document.querySelector('.inp23_1');
let inp23_2 = document.querySelector('.inp23_2');
let inp23_3 = document.querySelector('.inp23_3');
let btn23 = document.querySelector('#btn23');
let p23 = document.querySelector("#p23")
btn23.addEventListener('click', function(){
    let a = Number(inp23_1.value);
    let b = Number(inp23_2.value);
    let c = Number(inp23_3.value);
    let d = (b**2) - 4*a*c;
    if (d > 0){
        let x1= ((-b)-(Math.sqrt(d)))/2*a;
        let x2= ((-b)+(Math.sqrt(d)))/2*a;
        p23.textContent = 'Первый - '+ x1 + ' Второй ' + x2;
    } else if (d == 0){
        let x1 = -(b/(2*a));
        p23.textContent = x1;
    } else {
        p23.textContent = 'Нет корней';
    }
})